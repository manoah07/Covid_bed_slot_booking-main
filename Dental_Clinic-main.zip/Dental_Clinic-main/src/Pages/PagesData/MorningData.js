const MorningData =[
    {
        index:1,
        m_slot_time: "11:00 AM",
        color : ["green","white"],
    },
    {
        index:2,
        m_slot_time: "11:30 AM",
        color : ["green","white"],
    },
    {
        index:3,
        m_slot_time: "12:00 PM",
        color : ["green","white"],
    },
    {
        index:4,
        m_slot_time: "12:30 PM",
        color : ["green","white"],
    },
    {
        index:5,
        m_slot_time: "01:00 PM",
        color : ["green","white"],
    },
    {
        index:6,
        m_slot_time: "01:30 PM",
        color : ["green","white"],
    },
    {
        index:7,
        m_slot_time: "02:00 PM",
        color : ["green","white"],
    },
    {
        index:8,
        m_slot_time: "02:30 PM",
        color : ["green","white"],
    },
    {
        index:9,
        m_slot_time: "03:00 PM",
        color : ["green","white"],
    },
    {
        index:10,
        m_slot_time: "03:15 PM",
        color : ["green","white"],
    },
    {
        index:11,
        m_slot_time: "03:30 PM",
        color : ["green","white"],
    },
    {
        index:12,
        m_slot_time: "03:45 PM",
        color : ["green","white"],
    },
    {
        index:13,
        m_slot_time: "04:00 PM",
        color : ["green","white"],
    },
    {
        index:14,
        m_slot_time: "04:15 PM",
        color : ["green","white"],
    },
    {
        index:15,
        m_slot_time: "04:30 PM",
        color : ["green","white"],
    },
    {
        index:16,
        m_slot_time: "04:45 PM",
        color : ["green","white"],
    },
    
];

export default MorningData;