const about_long_des = {
  text: "We'll make sure to deliver the best possible healthcare to all our patients! Of course, we always complement our main services with a customer service oriented approach. We sincerely believe that visiting a dentist shouldn't be a frightening or stressful experience! We provide an equally comfortable experience of relaxation for all our young and adult customers! Also we implement a lot of pain management and anesthesia options.",
};

export default about_long_des;
