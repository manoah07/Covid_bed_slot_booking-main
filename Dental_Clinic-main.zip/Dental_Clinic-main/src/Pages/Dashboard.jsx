import React from "react";

const Dashboard = () => {
  return (
    <>
      <h2>this is the dashboard</h2>
    </>
  );
};

export default Dashboard;
